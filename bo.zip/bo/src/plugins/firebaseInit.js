// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyAdgl8bSAQqD8A0e3GSXJarCnwRY__l29E",
  authDomain: "bodatabase-ba770.firebaseapp.com",
  projectId: "bodatabase-ba770",
  storageBucket: "bodatabase-ba770.appspot.com",
  messagingSenderId: "744232238915",
  appId: "1:744232238915:web:20441a1e335fa249d639f6",
  measurementId: "G-ZBR1C95KP9",
});

const db = getFirestore(firebaseApp);
export default db;
